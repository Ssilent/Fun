// Kick Translator PL→EN: polski slang, skróty i przekleństwa.
// Przed tłumaczeniem slang jest zamieniany na zwykły polski albo od razu na angielski odpowiednik,
// bo zwykłe tłumacze często tłumaczą go dosłownie (np. "w chuj" albo "masakra").
// Ten sam plik działa w tle dodatku i na stronie Kick.
(function (root) {
  'use strict';

  // [polski slang, zamiennik, 'en' = angielski zamiennik / 'pl' = rozwinięcie po polsku]
  // Zwroty wielowyrazowe są sprawdzane przed pojedynczymi słowami.
  const ENTRIES = [
    // --- Przekleństwa: zwroty ---
    ['co do chuja', 'what the fuck', 'en'],
    ['co do kurwy', 'what the fuck', 'en'],
    ['chuj wie', 'fuck knows', 'en'],
    ['chuj z tym', 'fuck it', 'en'],
    ['w chuj', 'as fuck', 'en'],
    ['jebać to', 'fuck it', 'en'],
    ['pierdolę to', 'fuck it', 'en'],
    ['ja pierdolę', 'holy fuck', 'en'],
    ['o kurwa', 'oh fuck', 'en'],
    ['kurwa mać', 'fucking hell', 'en'],
    ['mam wyjebane', "I don't give a fuck", 'en'],
    ['mam to w dupie', "I don't give a shit", 'en'],
    ['no to dupa', 'well, that sucks', 'en'],
    ['nie pierdol', 'stop bullshitting', 'en'],
    ['odpierdol się', 'fuck off', 'en'],
    // --- Slang: zwroty ---
    ['ale beka z', 'lmao at', 'en'],
    ['ale beka', "that's hilarious", 'en'],
    ['beka z', 'laughing at', 'en'],
    ['ale essa', 'nice', 'en'],
    ['ale sztos', "that's awesome", 'en'],
    ['nie ma opcji', 'no way', 'en'],
    ['git majonez', 'all good', 'en'],
    ['spoko loko', 'cool', 'en'],
    ['ogarnij się', 'get a grip', 'en'],
    ['nie ogarniam', 'nie rozumiem', 'pl'],
    ['elo 320', 'hey', 'en'],

    // --- Przekleństwa: słowa ---
    ['jprdl', 'holy fuck', 'en'],
    ['jpdl', 'holy fuck', 'en'],
    ['kurwa', 'fuck', 'en'],
    ['kurła', 'fuck', 'en'],
    ['kurfa', 'fuck', 'en'],
    ['kurde', 'damn', 'en'],
    ['kurna', 'damn', 'en'],
    ['kurczę', 'damn', 'en'],
    ['chuj', 'dick', 'en'],
    ['chujowy', 'shitty', 'en'],
    ['chujowa', 'shitty', 'en'],
    ['chujowe', 'shitty', 'en'],
    ['chujowo', 'shitty', 'en'],
    ['jebać', 'fuck', 'en'],
    ['jebany', 'fucking', 'en'],
    ['jebana', 'fucking', 'en'],
    ['jebane', 'fucking', 'en'],
    ['zajebisty', 'fucking awesome', 'en'],
    ['zajebista', 'fucking awesome', 'en'],
    ['zajebiste', 'fucking awesome', 'en'],
    ['zajebiście', 'fucking awesome', 'en'],
    ['zajebioza', 'fucking awesome', 'en'],
    ['spierdalaj', 'fuck off', 'en'],
    ['wypierdalaj', 'fuck off', 'en'],
    ['pierdolisz', "you're talking shit", 'en'],
    ['pierdolony', 'fucking', 'en'],
    ['pierdolona', 'fucking', 'en'],
    ['pierdolone', 'fucking', 'en'],
    ['skurwysyn', 'son of a bitch', 'en'],
    ['skurwiel', 'bastard', 'en'],
    ['skurwielu', 'bastard', 'en'],
    ['gówno', 'shit', 'en'],
    ['gówniany', 'shitty', 'en'],
    ['gówniana', 'shitty', 'en'],
    ['gówniane', 'shitty', 'en'],
    ['pizda', 'pussy', 'en'],
    ['suka', 'bitch', 'en'],
    ['dupa', 'ass', 'en'],
    ['debil', 'moron', 'en'],
    ['dzban', 'idiot', 'en'],
    ['dzbanie', 'idiot', 'en'],

    // --- Slang: słowa ---
    ['siema', 'hey', 'en'],
    ['siemka', 'hey', 'en'],
    ['siemano', 'hey', 'en'],
    ['siemanko', 'hey', 'en'],
    ['elo', 'hey', 'en'],
    ['elko', 'hey', 'en'],
    ['eluwa', 'hey', 'en'],
    ['elo320', 'hey', 'en'],
    ['hejka', 'hey', 'en'],
    ['hejo', 'hey', 'en'],
    ['czołem', 'hey', 'en'],
    ['nara', 'bye', 'en'],
    ['narka', 'bye', 'en'],
    ['pozdro', 'cheers', 'en'],
    ['pozdrówka', 'cheers', 'en'],
    ['pzdr', 'cheers', 'en'],
    ['dzięks', 'thanks', 'en'],
    ['dzięx', 'thanks', 'en'],
    ['dzk', 'thanks', 'en'],
    ['nmzc', "you're welcome", 'en'],
    ['spoko', 'cool', 'en'],
    ['spoks', 'cool', 'en'],
    ['spox', 'cool', 'en'],
    ['spoczko', 'cool', 'en'],
    ['spk', 'cool', 'en'],
    ['git', 'cool', 'en'],
    ['gites', 'cool', 'en'],
    ['gituwa', 'cool', 'en'],
    ['sztos', 'awesome', 'en'],
    ['sztosik', 'awesome', 'en'],
    ['essa', 'nice', 'en'],
    ['kozak', 'awesome', 'en'],
    ['kozacko', 'awesome', 'en'],
    ['kozacki', 'awesome', 'en'],
    ['kozacka', 'awesome', 'en'],
    ['kozackie', 'awesome', 'en'],
    ['beka', 'lol', 'en'],
    ['masakra', 'insane', 'en'],
    ['elegancko', 'nice', 'en'],
    ['kox', 'beast', 'en'],
    ['ziom', 'bro', 'en'],
    ['ziomek', 'bro', 'en'],
    ['ziomal', 'bro', 'en'],
    ['ziomuś', 'bro', 'en'],
    ['ziomie', 'bro', 'en'],
    ['ziomki', 'bros', 'en'],
    ['ziomale', 'bros', 'en'],
    ['mordo', 'bro', 'en'],
    ['mordeczko', 'bro', 'en'],
    ['mordzia', 'bro', 'en'],
    ['byku', 'dude', 'en'],
    ['byczku', 'dude', 'en'],
    ['byq', 'dude', 'en'],
    ['lamus', 'loser', 'en'],
    ['lamusie', 'loser', 'en'],
    ['przegryw', 'loser', 'en'],
    ['bambik', 'noob', 'en'],
    ['bambiku', 'noob', 'en'],
    ['sory', 'sorry', 'en'],
    ['sorki', 'sorry', 'en'],
    ['sorka', 'sorry', 'en'],
    ['oki', 'ok', 'en'],
    ['okej', 'ok', 'en'],
    ['zw', 'brb', 'en'],
    ['jj', "I'm back", 'en'],
    ['dawaj', 'come on', 'en'],
    ['dawajcie', 'come on', 'en'],
    ['lecimy', "let's go", 'en'],
    ['krindż', 'cringe', 'en'],
    ['krinż', 'cringe', 'en'],
    // Skróty i słowa, które lepiej rozwinąć po polsku (tłumacz zachowa gramatykę zdania)
    ['nwm', 'nie wiem', 'pl'],
    ['nw', 'nie wiem', 'pl'],
    ['wgl', 'w ogóle', 'pl'],
    ['wogóle', 'w ogóle', 'pl'],
    ['sb', 'sobie', 'pl'],
    ['cb', 'ciebie', 'pl'],
    ['tb', 'tobie', 'pl'],
    ['kc', 'kocham cię', 'pl'],
    ['kcm', 'kocham cię', 'pl'],
    ['cza', 'trzeba', 'pl'],
    ['kumam', 'rozumiem', 'pl'],
    ['czaję', 'rozumiem', 'pl'],
    ['czaisz', 'rozumiesz', 'pl'],
    ['kumasz', 'rozumiesz', 'pl'],
    ['dlaczemu', 'dlaczego', 'pl'],
    ['gierka', 'gra', 'pl'],
    ['giereczka', 'gra', 'pl']
  ];

  const DIACRITIC = { ą: '[ąa]', ć: '[ćc]', ę: '[ęe]', ł: '[łl]', ń: '[ńn]', ó: '[óo]', ś: '[śs]', ź: '[źzż]', ż: '[żzź]' };
  const esc = (c) => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  function keyToPattern(key) {
    const words = key.split(' ');
    const parts = words.map((w, wi) => {
      const chars = Array.from(w).map((c) => DIACRITIC[c] || esc(c));
      // W pojedynczych słowach ostatnia litera może się powtarzać: "siemaaa", "kurwaaa"
      if (words.length === 1 || wi === words.length - 1) chars[chars.length - 1] += '+';
      return chars.join('');
    });
    return parts.join('\\s+');
  }

  const BEFORE = '(?<![\\p{L}\\p{N}_@])';
  const AFTER = '(?![\\p{L}\\p{N}_])';
  const sorted = ENTRIES.slice().sort((a, b) => b[0].length - a[0].length);
  const compiled = sorted.map(([key, repl, kind]) => ({
    key,
    repl,
    kind,
    re: new RegExp(BEFORE + '(' + keyToPattern(key) + ')' + AFTER, 'giu')
  }));

  function matchCase(found, repl) {
    const letters = found.replace(/[^\p{L}]/gu, '');
    if (letters.length > 1 && letters === letters.toUpperCase() && letters !== letters.toLowerCase()) {
      return repl.toUpperCase();
    }
    if (found[0] && found[0] !== found[0].toLowerCase()) return repl[0].toUpperCase() + repl.slice(1);
    return repl;
  }

  // Zamienia slang na zwykły polski lub angielski. onlyEnglish: tylko zamienniki angielskie
  // (używane do poprawiania resztek polskich słów w gotowym tłumaczeniu).
  function normalize(text, onlyEnglish) {
    let out = String(text);
    for (const e of compiled) {
      if (onlyEnglish && e.kind !== 'en') continue;
      out = out.replace(e.re, (m) => matchCase(m, e.repl));
    }
    return out;
  }

  const SWEARS = [
    /\b(mother)?fuck(ing|in|er|ers|ed|s)?\b/gi,
    /\bbullshit(ting)?\b/gi,
    /\bshit(ty|s)?\b/gi,
    /\bbitch(es)?\b/gi,
    /\bass(hole|holes)?\b/gi,
    /\bdick(s|head)?\b/gi,
    /\bcunt(s)?\b/gi,
    /\bpussy\b/gi,
    /\bbastard(s)?\b/gi,
    /\bwhore(s)?\b/gi
  ];
  function censor(text) {
    let out = String(text);
    for (const re of SWEARS) out = out.replace(re, (m) => m[0] + '*'.repeat(m.length - 1));
    return out;
  }

  // Słowa, które mocno wskazują na polski (do wykrywania polskich wiadomości).
  const strong = new Set();
  const weak = new Set();
  for (const [key] of ENTRIES) {
    if (key.includes(' ')) continue;
    (key.length <= 2 ? weak : strong).add(key);
    const plain = key.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ł/g, 'l');
    if (plain !== key) (plain.length <= 2 ? weak : strong).add(plain);
  }
  for (const w of ['git', 'oki', 'sory']) { strong.delete(w); weak.add(w); }

  root.KPE_SLANG = { normalize, censor, strong, weak, size: ENTRIES.length };
})(typeof self !== 'undefined' ? self : this);
