// Kick Translator PL→EN: teksty interfejsu po polsku i po angielsku.
(function (root) {
  'use strict';
  const STRINGS = {
    pl: {
      appName: 'Kick Tłumacz PL→EN',
      subtitle: 'Polskie wiadomości na czacie Kick dostają tłumaczenie na angielski.',
      incoming: 'Tłumacz wiadomości na czacie',
      whichTitle: 'Które wiadomości',
      whichPl: 'Tylko po polsku',
      whichAll: 'Wszystkie, które nie są po angielsku',
      displayTitle: 'Jak pokazać tłumaczenie',
      displayBelow: 'Pod oryginalną wiadomością',
      displayReplace: 'Zamiast oryginału (oryginał po najechaniu myszką)',
      slangTitle: 'Slang i przekleństwa',
      slang: 'Rozpoznawaj polski slang i skróty (siema, nwm, sztos, mordo…)',
      censor: 'Cenzuruj przekleństwa w tłumaczeniu (f***)',
      slangHint: 'Przekleństwa są tłumaczone na angielskie odpowiedniki. Włącz cenzurę, jeśli wolisz ich nie widzieć.',
      provider: 'Tłumacz',
      provGoogle: 'Google (darmowy)',
      provMyMemory: 'MyMemory (darmowy, limit dzienny)',
      provDeepL: 'DeepL (najlepsza jakość, klucz API)',
      deeplKey: 'Klucz DeepL API',
      deeplHint: 'Darmowy klucz: deepl.com/pro-api (plan Free). Klucz zostaje tylko na tym komputerze.',
      testTitle: 'Szybki test',
      testPlaceholder: 'Wpisz wiadomość po polsku…',
      testBtn: 'Przetłumacz',
      testBusy: 'Tłumaczę…',
      testAlreadyEn: 'To już jest po angielsku.',
      testDetected: 'Wykryty język: {lang}.',
      testProvider: 'Tłumacz: {name}.',
      testFail: 'Nie udało się przetłumaczyć.',
      outTitle: 'Dodatkowo: moje wiadomości',
      outgoing: 'Tłumacz też to, co ja piszę (wysyłam po angielsku)',
      modeSend: 'Enter tłumaczy i od razu wysyła',
      modePreview: 'Enter tłumaczy, drugi Enter wysyła',
      outHint: 'Ctrl+Enter tylko tłumaczy. Alt+Enter wysyła bez tłumaczenia.',
      footHint: 'Alt+T na stronie Kick włącza lub wyłącza tłumaczenie czatu. To samo robi plakietka "PL→EN" przy czacie.',
      langLabel: 'Język menu',
      badgeOn: 'PL→EN · Wł.',
      badgeOff: 'PL→EN · Wył.',
      badgeTip: 'Tłumaczenie polskich wiadomości na czacie na angielski.\nKliknij, żeby włączyć lub wyłączyć (Alt+T).',
      badgeTipOut: '\n\nTwoje wiadomości: Enter tłumaczy i wysyła, Alt+Enter wysyła bez tłumaczenia.',
      stOn: 'Tłumaczenie czatu włączone.',
      stOff: 'Tłumaczenie czatu wyłączone.',
      stReload: 'Dodatek został zaktualizowany. Odśwież stronę (F5).',
      stIncomingFail: 'Nie udało się przetłumaczyć wiadomości (brak internetu lub serwis niedostępny).',
      stBusy: 'Tłumaczę…',
      stStillBusy: 'Chwila, jeszcze tłumaczę…',
      stSentOriginal: 'Wysłano bez tłumaczenia.',
      stChanged: 'Tekst zmienił się w trakcie tłumaczenia. Spróbuj jeszcze raz.',
      stInsertFail: 'Nie udało się wstawić tłumaczenia do czatu. Enter wyśle tekst bez zmian.',
      stTooLong: 'Tłumaczenie ma {n} znaków (limit Kick: {max}). Skróć je i naciśnij Enter.',
      stPreview: 'Gotowe. Sprawdź tekst i naciśnij Enter, żeby wysłać.',
      stSent: 'Wysłano: {text}',
      stPressEnter: 'Tłumaczenie gotowe. Naciśnij Enter, żeby wysłać.',
      stOutFail: 'Błąd tłumaczenia (brak internetu lub serwis niedostępny). Enter wyśle tekst bez tłumaczenia.',
      original: 'Oryginał: ',
      langs: { pl: 'polski', de: 'niemiecki', cs: 'czeski', sk: 'słowacki', uk: 'ukraiński', ru: 'rosyjski', es: 'hiszpański', fr: 'francuski', it: 'włoski', pt: 'portugalski', en: 'angielski' }
    },
    en: {
      appName: 'Kick Translator PL→EN',
      subtitle: 'Polish messages in Kick chat get an English translation.',
      incoming: 'Translate chat messages',
      whichTitle: 'Which messages',
      whichPl: 'Polish only',
      whichAll: 'Everything that is not in English',
      displayTitle: 'How to show the translation',
      displayBelow: 'Below the original message',
      displayReplace: 'Instead of the original (hover to see the original)',
      slangTitle: 'Slang and swear words',
      slang: 'Understand Polish slang and abbreviations (siema, nwm, sztos, mordo…)',
      censor: 'Censor swear words in translations (f***)',
      slangHint: 'Swear words are translated into their English equivalents. Turn on censoring if you would rather not see them.',
      provider: 'Translator',
      provGoogle: 'Google (free)',
      provMyMemory: 'MyMemory (free, daily limit)',
      provDeepL: 'DeepL (best quality, API key)',
      deeplKey: 'DeepL API key',
      deeplHint: 'Free key: deepl.com/pro-api (Free plan). The key stays on this computer only.',
      testTitle: 'Quick test',
      testPlaceholder: 'Type a message in Polish…',
      testBtn: 'Translate',
      testBusy: 'Translating…',
      testAlreadyEn: 'This is already in English.',
      testDetected: 'Detected language: {lang}.',
      testProvider: 'Translator: {name}.',
      testFail: 'Could not translate.',
      outTitle: 'Extra: my own messages',
      outgoing: 'Also translate what I type (I send it in English)',
      modeSend: 'Enter translates and sends right away',
      modePreview: 'Enter translates, a second Enter sends',
      outHint: 'Ctrl+Enter only translates. Alt+Enter sends without translating.',
      footHint: 'Alt+T on Kick turns chat translation on or off. The "PL→EN" badge next to the chat does the same.',
      langLabel: 'Menu language',
      badgeOn: 'PL→EN · On',
      badgeOff: 'PL→EN · Off',
      badgeTip: 'Translates Polish chat messages into English.\nClick to turn on or off (Alt+T).',
      badgeTipOut: '\n\nYour messages: Enter translates and sends, Alt+Enter sends without translating.',
      stOn: 'Chat translation on.',
      stOff: 'Chat translation off.',
      stReload: 'The add-on was updated. Refresh the page (F5).',
      stIncomingFail: 'Could not translate messages (no internet or the service is unavailable).',
      stBusy: 'Translating…',
      stStillBusy: 'One moment, still translating…',
      stSentOriginal: 'Sent without translating.',
      stChanged: 'The text changed while translating. Try again.',
      stInsertFail: 'Could not put the translation into the chat box. Enter will send the text unchanged.',
      stTooLong: 'The translation has {n} characters (Kick limit: {max}). Shorten it and press Enter.',
      stPreview: 'Done. Check the text and press Enter to send.',
      stSent: 'Sent: {text}',
      stPressEnter: 'Translation ready. Press Enter to send.',
      stOutFail: 'Translation error (no internet or the service is unavailable). Enter will send the original text.',
      original: 'Original: ',
      langs: { pl: 'Polish', de: 'German', cs: 'Czech', sk: 'Slovak', uk: 'Ukrainian', ru: 'Russian', es: 'Spanish', fr: 'French', it: 'Italian', pt: 'Portuguese', en: 'English' }
    }
  };

  function resolveLang(pref) {
    if (pref === 'pl' || pref === 'en') return pref;
    let ui = '';
    try { ui = chrome.i18n.getUILanguage(); } catch (_) { ui = navigator.language || ''; }
    return String(ui).toLowerCase().startsWith('pl') ? 'pl' : 'en';
  }

  function t(lang, key, vars) {
    const table = STRINGS[lang] || STRINGS.en;
    let s = table[key] !== undefined ? table[key] : STRINGS.en[key];
    if (typeof s === 'string' && vars) s = s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : ''));
    return s;
  }

  root.KPE_I18N = { STRINGS, resolveLang, t };
})(typeof self !== 'undefined' ? self : this);
