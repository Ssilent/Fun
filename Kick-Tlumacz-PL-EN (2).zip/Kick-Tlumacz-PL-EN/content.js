// Kick Tłumacz PL→EN
// 1) Tłumaczy polskie wiadomości innych osób na czacie Kick na angielski (główna funkcja).
// 2) Opcjonalnie tłumaczy Twoje własne wiadomości przed wysłaniem (domyślnie wyłączone).
(() => {
  'use strict';
  if (window.__kickPlEnLoaded) return;
  window.__kickPlEnLoaded = true;

  const DEFAULTS = {
    incoming: true, // tłumacz wiadomości na czacie
    which: 'pl', // 'pl' = tylko po polsku, 'all' = wszystko, co nie jest po angielsku
    display: 'below', // 'below' = pod oryginałem, 'replace' = zamiast oryginału
    outgoing: false, // tłumacz moje wiadomości przed wysłaniem
    mode: 'send', // dla moich wiadomości: 'send' albo 'preview'
    provider: 'google',
    slang: true, // rozpoznawaj polski slang i skróty
    censor: false, // cenzuruj przekleństwa w tłumaczeniu
    uiLang: 'auto' // język komunikatów: 'auto', 'pl', 'en'
  };
  const MAX_LEN = 500;
  const EDITOR_SELECTORS = [
    '.editor-input[contenteditable="true"]',
    '[data-lexical-editor="true"][contenteditable="true"]',
    '#message-input[contenteditable="true"]',
    '#chat-input-wrapper [contenteditable="true"]',
    '[data-testid*="chat-input"] [contenteditable="true"]'
  ];
  // Treść wiadomości na czacie Kick (kilka wariantów, bo Kick zmienia wygląd).
  const CONTENT_SELECTORS_GLOBAL = [
    'span.font-normal[class*="leading-[1.55]"]',
    '.chat-entry-content',
    '.chat-message-content',
    '[data-chat-entry] .message',
    '.chat-entry .message'
  ].join(',');
  const CONTENT_SELECTORS_IN_CHAT = 'span.font-normal[class*="leading-"]';
  const ROW_SELECTORS = 'div[style*="--chatroom-font-size"], [data-chat-entry], .chat-entry, [data-index]';
  const CHAT_CONTAINER_SELECTORS = '#chatroom-messages, #chat-messages, [data-testid="chat-messages"]';
  const EMBED_SELECTOR = 'img,[data-emote-id],[data-emote-name],[data-lexical-decorator="true"]';
  const PROTECT_RE = /(\[emote:\d+:[^\]\s]+\]|https?:\/\/\S+|www\.\S+|@[\w.\-]+)/g;
  const LETTER_RE = /\p{L}/u;

  let settings = { ...DEFAULTS };
  const T = (key, vars) => self.KPE_I18N.t(self.KPE_I18N.resolveLang(settings.uiLang), key, vars);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => String(s || '').replace(/[\u200b\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  const short = (s, n = 70) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

  // ---------- Ustawienia ----------
  function loadSettings() {
    try {
      chrome.storage.sync.get(DEFAULTS, (s) => {
        if (chrome.runtime.lastError) return;
        settings = { ...DEFAULTS, ...s };
        renderBadge();
        resetIncoming();
      });
    } catch (_) { /* dodatek przeładowany */ }
  }
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      let incomingChanged = false;
      for (const [k, v] of Object.entries(changes)) {
        settings[k] = v.newValue === undefined ? DEFAULTS[k] : v.newValue;
        if (['incoming', 'which', 'display', 'provider', 'slang', 'censor'].includes(k)) incomingChanged = true;
      }
      renderBadge();
      if (incomingChanged) resetIncoming();
    });
  } catch (_) { /* ignore */ }

  function toggleIncoming() {
    settings.incoming = !settings.incoming;
    renderBadge();
    resetIncoming();
    setStatus('info', settings.incoming ? T('stOn') : T('stOff'));
    try { chrome.storage.sync.set({ incoming: settings.incoming }); } catch (_) { /* ignore */ }
  }

  // ---------- Wspólne: tłumaczenie przez dodatek ----------
  const cache = new Map();
  function requestTranslation(text, source, hint) {
    const key = [settings.provider, source, settings.slang, settings.censor, hint || '', text].join('|');
    if (cache.has(key)) return Promise.resolve(cache.get(key));
    return new Promise((resolve, reject) => {
      try {
        const msg = { type: 'translate', text, source, provider: settings.provider, slang: settings.slang, censor: settings.censor, hint: hint || '' };
        chrome.runtime.sendMessage(msg, (resp) => {
          const le = chrome.runtime.lastError;
          if (le) return reject(new Error(le.message));
          if (!resp || !resp.ok) return reject(new Error((resp && resp.error) || 'Brak odpowiedzi'));
          if (cache.size > 1000) cache.clear();
          cache.set(key, resp);
          resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  // Dzieli tekst na fragmenty do tłumaczenia i chronione (emotki, linki, @wzmianki).
  async function translateParts(text, source) {
    const parts = String(text).split(PROTECT_RE);
    return Promise.all(
      parts.map(async (p, i) => {
        if (i % 2 === 1) return { token: true, value: p };
        if (!LETTER_RE.test(p)) return { token: false, value: p };
        const lead = p.match(/^\s*/)[0];
        const trail = p.match(/\s*$/)[0];
        const r = await requestTranslation(p.trim(), source);
        return { token: false, value: lead + r.text + trail };
      })
    );
  }
  const joinParts = (parts) => parts.map((p) => p.value).join('').replace(/[ \t]+/g, ' ').trim();

  function emoteToken(el) {
    const img = el.tagName === 'IMG' ? el : el.querySelector('img');
    let id = el.getAttribute('data-emote-id') || (img && img.getAttribute('data-emote-id'));
    let name =
      el.getAttribute('data-emote-name') ||
      (img && (img.getAttribute('data-emote-name') || img.getAttribute('alt'))) ||
      '';
    if (!id && img) {
      const m = (img.getAttribute('src') || '').match(/emotes\/(\d+)/);
      if (m) id = m[1];
    }
    name = name.replace(/^:+|:+$/g, '').trim();
    if (id && name && !/\s/.test(name)) return ' [emote:' + id + ':' + name + '] ';
    return name ? ' ' + name + ' ' : ' ';
  }

  // Czyta tekst z elementu (emotki jako [emote:id:nazwa]).
  function readText(root) {
    let out = '';
    const walk = (node) => {
      if (node.nodeType === Node.TEXT_NODE) { out += node.nodeValue; return; }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const el = node;
      if (el.classList.contains('kpe-tr')) return;
      if (el.tagName === 'BR') { out += ' '; return; }
      if (el !== root && el.matches(EMBED_SELECTOR)) { out += emoteToken(el); return; }
      if (el !== root && /^(P|DIV|LI)$/.test(el.tagName) && out && !/\s$/.test(out)) out += ' ';
      for (const ch of el.childNodes) walk(ch);
    };
    walk(root);
    return norm(out);
  }

  // =====================================================================
  // 1) WIADOMOŚCI INNYCH OSÓB: tłumaczenie na czacie
  // =====================================================================
  const PL_CHARS = /[ąćęłńśźżĄĆĘŁŃŚŹŻ]/;
  const PL_STRONG = new Set((
    'nie jest się sie jak czy dzięki dzieki dzięks dzieks siema siemka siemano elo cześć czesc hejka witam witajcie ' +
    'kurwa kurde chyba bardzo wszystko wszyscy dobra dobry dobre dobrze kiedy gdzie dlaczego czemu już juz ' +
    'jeszcze tylko teraz był byl była byla było bylo będzie bedzie mnie ciebie tobie tego który ktory która ' +
    'ktora które ktore też tez może moze coś cos ktoś ktos nic mam masz jestem jesteś jestes jesteśmy jestesmy ' +
    'mój moj twój twoj moja twoja gra gram grasz gość gosc ziom ziomek ziomal mordo mordeczko byku kocham ' +
    'lubię lubie pozdro pozdrawiam fajnie fajny fajna fajne zajebiste zajebisty dzień dzien dobranoc dziękuję ' +
    'dziekuje proszę prosze właśnie wlasnie trochę troche ładnie ladnie gramy idziemy chodź chodz patrz zobacz ' +
    'wiem wiesz myślę mysle chcę chce chcesz będę bede jutro dzisiaj dziś dzis wczoraj jaki jaka jakie sobie ' +
    'siebie polska polski polsko polak polacy kolego kolega serio naprawdę naprawde mega spoko'
  ).split(/\s+/));
  const PL_WEAK = new Set('co to tak ale ty ja ze za od po na do w z i a o u mi ci ten ta te tu tam no'.split(/\s+/));
  for (const w of self.KPE_SLANG.strong) PL_STRONG.add(w);
  for (const w of self.KPE_SLANG.weak) PL_WEAK.add(w);
  const EN_WORDS = new Set((
    'the is are you your what this that and of it for with have has was be my me so just lol lmao he she they ' +
    'we can dont don\'t im i\'m it\'s its in on at not but if how why who when all good nice bro yes yeah ' +
    'play game stream chat love thanks thank please wow omg gg ez'
  ).split(/\s+/));

  function words(plain) {
    return plain.toLowerCase().split(/[^\p{L}']+/u).filter(Boolean);
  }
  function polishScore(plain) {
    let score = PL_CHARS.test(plain) ? 3 : 0;
    if (self.KPE_SLANG.normalize(plain) !== plain) score += 2; // polski slang lub przekleństwa
    for (const w of words(plain)) {
      if (PL_STRONG.has(w)) score += 2;
      else if (PL_WEAK.has(w)) score += 1;
      else if (EN_WORDS.has(w)) score -= 1;
    }
    return score;
  }
  const looksPolish = (plain) => polishScore(plain) >= 2;
  function looksEnglish(plain) {
    if (/[^\x00-\x7f]/.test(plain.replace(/[^\p{L}]/gu, ''))) return false;
    if (looksPolish(plain)) return false;
    const w = words(plain);
    return w.some((x) => EN_WORDS.has(x)) || w.length <= 1;
  }

  function shouldConsider(text, plain) {
    if (!settings.incoming) return false;
    if (/^[!\/]/.test(text)) return false; // komendy botów
    if ((plain.match(/\p{L}/gu) || []).length < 2) return false; // same emotki lub znaki
    return settings.which === 'all' ? !looksEnglish(plain) : looksPolish(plain);
  }

  function chatContainer() {
    return document.querySelector(CHAT_CONTAINER_SELECTORS);
  }

  function findMessageContents() {
    const container = chatContainer();
    const found = new Set();
    const add = (list) => { for (const el of list) found.add(el); };
    add(Array.from(document.querySelectorAll(CONTENT_SELECTORS_GLOBAL)).slice(-80));
    if (container) {
      add(Array.from(container.querySelectorAll(CONTENT_SELECTORS_IN_CHAT)).slice(-80));
      // Plan B: wiersz z "nazwa: treść" bez znanych klas
      for (const row of Array.from(container.querySelectorAll(ROW_SELECTORS)).slice(-60)) {
        if (row.querySelector(CONTENT_SELECTORS_GLOBAL + ',' + CONTENT_SELECTORS_IN_CHAT)) continue;
        const sep = Array.from(row.querySelectorAll('span')).find(
          (s) => s.textContent.trim() === ':' && s.nextElementSibling && !s.nextElementSibling.classList.contains('kpe-tr')
        );
        if (sep) found.add(sep.nextElementSibling);
      }
    }
    const result = [];
    for (const el of found) {
      if (el.closest('.kpe-tr') || el.closest('[contenteditable="true"]') || el.closest('#kick-pl-en-translator')) continue;
      if (el.querySelector(CONTENT_SELECTORS_GLOBAL)) continue; // bierzemy najgłębszy element z treścią
      result.push(el);
    }
    return result;
  }

  const trFor = new WeakMap(); // element z treścią -> element z tłumaczeniem

  function removeTranslation(el) {
    const tr = trFor.get(el);
    if (tr) tr.remove();
    trFor.delete(el);
    el.removeAttribute('data-kpe-hidden');
  }

  function resetIncoming() {
    for (const tr of document.querySelectorAll('.kpe-tr')) tr.remove();
    for (const el of document.querySelectorAll('[data-kpe-src]')) {
      el.removeAttribute('data-kpe-src');
      el.removeAttribute('data-kpe-hidden');
    }
    queue.length = 0;
    scheduleScan();
  }

  // Kolejka: najnowsze wiadomości najpierw, maks. 3 naraz.
  const queue = [];
  let active = 0;
  function enqueue(job) {
    queue.push(job);
    if (queue.length > 40) queue.splice(0, queue.length - 40);
    pump();
  }
  function pump() {
    while (active < 3 && queue.length) {
      const job = queue.pop();
      active++;
      job().catch(reportError).finally(() => { active--; pump(); });
    }
  }

  let lastErrAt = 0;
  function reportError(e) {
    const msg = String((e && e.message) || e);
    if (/context invalidated|Extension context/i.test(msg)) {
      setStatus('error', T('stReload'));
      return;
    }
    console.warn('[Kick PL→EN]', msg);
    if (Date.now() - lastErrAt > 30000) {
      lastErrAt = Date.now();
      setStatus('error', T('stIncomingFail'));
    }
  }

  function processContent(el) {
    const text = readText(el);
    if (el.getAttribute('data-kpe-src') === text) return;
    removeTranslation(el); // treść się zmieniła (Kick używa elementów ponownie)
    el.setAttribute('data-kpe-src', text);
    const plain = norm(text.replace(PROTECT_RE, ' '));
    if (!shouldConsider(text, plain)) return;
    enqueue(() => translateIncoming(el, text, plain));
  }

  async function translateIncoming(el, text, plain) {
    if (!el.isConnected || el.getAttribute('data-kpe-src') !== text || !settings.incoming) return;
    const r = await requestTranslation(plain, 'auto', polishScore(plain) >= 4 ? 'pl' : '');
    const d = String(r.detected || '').toLowerCase();
    if (r.unchanged || d.startsWith('en')) return;
    if (settings.which === 'pl' && d && d !== 'pl') return;

    let parts;
    PROTECT_RE.lastIndex = 0;
    if (PROTECT_RE.test(text)) {
      parts = await translateParts(text, d && d !== 'auto' ? d : 'pl');
    } else {
      parts = [{ token: false, value: r.text }];
    }
    PROTECT_RE.lastIndex = 0;
    const out = joinParts(parts);
    if (!out || out.toLowerCase() === text.toLowerCase()) return;
    if (!el.isConnected || el.getAttribute('data-kpe-src') !== text || !settings.incoming) return;
    renderTranslation(el, parts, text);
  }

  function findScroller(el) {
    for (let n = el.parentElement; n && n !== document.body; n = n.parentElement) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 4) return n;
    }
    return null;
  }

  function renderTranslation(el, parts, original) {
    removeTranslation(el);
    const replace = settings.display === 'replace';
    const tr = document.createElement(replace ? 'span' : 'div');
    tr.className = 'kpe-tr' + (replace ? ' kpe-replace' : '');
    tr.setAttribute('lang', 'en');
    const tag = document.createElement('span');
    tag.className = 'kpe-tag';
    tag.textContent = 'EN';
    tr.append(tag);
    for (const p of parts) {
      const m = p.token && p.value.match(/^\[emote:(\d+):([^\]]+)\]$/);
      if (m) {
        const src =
          el.querySelector('[data-emote-id="' + m[1] + '"]') ||
          Array.from(el.querySelectorAll('img')).find((i) => (i.getAttribute('src') || '').includes('/emotes/' + m[1]));
        tr.append(src ? src.cloneNode(true) : document.createTextNode(m[2]));
      } else {
        tr.append(document.createTextNode(p.value));
      }
    }
    if (replace) {
      tr.title = T('original') + original.replace(/\[emote:\d+:([^\]]+)\]/g, '$1');
      el.setAttribute('data-kpe-hidden', '');
    }
    const scroller = findScroller(el);
    const pinned = scroller && scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 80;
    el.after(tr);
    trFor.set(el, tr);
    tr.__kpeFor = el;
    if (pinned) scroller.scrollTop = scroller.scrollHeight;
  }

  function scan() {
    // Sprzątanie: tłumaczenia, których wiadomość zniknęła lub się przesunęła.
    for (const tr of document.querySelectorAll('.kpe-tr')) {
      const owner = tr.__kpeFor;
      if (!owner || !owner.isConnected || owner.nextElementSibling !== tr) tr.remove();
    }
    if (!settings.incoming) return;
    for (const el of findMessageContents()) processContent(el);
  }

  let scanTimer = null;
  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = null; scan(); }, 200);
  }

  const style = document.createElement('style');
  style.id = 'kpe-style';
  style.textContent = `
    .kpe-tr { display:block; margin:2px 0 1px; padding-left:8px; border-left:2px solid #53fc18; color:#dcffd0;
              font-size:.95em; line-height:1.45; white-space:normal; overflow-wrap:anywhere; }
    .kpe-tr.kpe-replace { display:inline; margin:0; padding:0; border:0; color:inherit; cursor:help; }
    .kpe-tr img { height:1.6em; width:auto; vertical-align:middle; }
    .kpe-tag { display:inline-block; margin-right:6px; padding:0 4px; border-radius:3px; background:#53fc18; color:#0b0c0e;
               font:700 .68em/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; vertical-align:middle; letter-spacing:.03em; }
    [data-kpe-hidden] { display:none !important; }
  `;
  (document.head || document.documentElement).appendChild(style);

  new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // =====================================================================
  // 2) MOJE WIADOMOŚCI (opcjonalnie): tłumaczenie przed wysłaniem
  // =====================================================================
  let busy = false;
  let bypass = false;
  let previewPending = false;
  let sendOriginalNext = false;

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  function findEditor() {
    for (const sel of EDITOR_SELECTORS) {
      for (const el of document.querySelectorAll(sel)) if (isVisible(el)) return el;
    }
    return null;
  }
  function editorFrom(target) {
    if (!(target instanceof Element)) return null;
    const ed = target.closest('[contenteditable="true"]');
    if (!ed) return null;
    return EDITOR_SELECTORS.some((sel) => ed.matches(sel)) ? ed : null;
  }
  const readEditor = readText;

  function textNodes(editor) {
    const list = [];
    const tw = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) =>
        LETTER_RE.test(n.nodeValue) && !(n.parentElement && n.parentElement.closest(EMBED_SELECTOR))
          ? NodeFilter.FILTER_ACCEPT
          : NodeFilter.FILTER_REJECT
    });
    while (tw.nextNode()) list.push(tw.currentNode);
    return list;
  }
  function placeSelection(editor, range) {
    editor.focus({ preventScroll: true });
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
  function selectAll(editor) {
    const r = document.createRange();
    r.selectNodeContents(editor);
    placeSelection(editor, r);
  }
  async function writeEditor(editor, text) {
    selectAll(editor);
    await sleep(30);
    document.execCommand('insertText', false, text);
    await sleep(60);
    if (norm(readEditor(editor)) === norm(text)) return true;
    selectAll(editor);
    await sleep(30);
    try {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      editor.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch (_) { /* ignore */ }
    await sleep(80);
    return norm(readEditor(editor)) === norm(text);
  }
  async function translateMessageOut(text) {
    return joinParts(await translateParts(text, 'pl'));
  }
  async function translateInPlace(editor) {
    const originals = textNodes(editor).map((n) => n.nodeValue);
    const translated = await Promise.all(originals.map((t) => translateMessageOut(t)));
    for (let i = originals.length - 1; i >= 0; i--) {
      const node = textNodes(editor)[i];
      if (!node || node.nodeValue !== originals[i]) throw userError(T('stChanged'));
      const v = node.nodeValue;
      const lead = v.length - v.replace(/^\s+/, '').length;
      const trail = v.length - v.replace(/\s+$/, '').length;
      const r = document.createRange();
      r.setStart(node, lead);
      r.setEnd(node, v.length - trail);
      placeSelection(editor, r);
      await sleep(30);
      document.execCommand('insertText', false, translated[i]);
      await sleep(40);
    }
    const now = readEditor(editor);
    if (!translated.every((t) => now.includes(norm(t)))) throw userError(T('stInsertFail'));
  }
  function findSendButton(editor) {
    let node = editor;
    for (let depth = 0; depth < 7 && node; depth++, node = node.parentElement) {
      for (const b of node.querySelectorAll('button, [role="button"]')) {
        if (b.disabled || !isVisible(b)) continue;
        const label = [b.id, b.getAttribute('aria-label'), b.getAttribute('title'), b.textContent].join(' ').trim();
        if (/send-message|send|wyślij|^\s*chat\s*$/i.test(label)) return b;
      }
    }
    return null;
  }
  function pressEnter(editor) {
    bypass = true;
    try {
      editor.focus({ preventScroll: true });
      const init = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
      editor.dispatchEvent(new KeyboardEvent('keydown', init));
      editor.dispatchEvent(new KeyboardEvent('keyup', init));
    } finally {
      bypass = false;
    }
  }
  async function waitUntilGone(editor, expected, ms) {
    const until = Date.now() + ms;
    while (Date.now() < until) {
      if (norm(readEditor(editor)) !== norm(expected)) return true;
      await sleep(40);
    }
    return norm(readEditor(editor)) !== norm(expected);
  }
  async function sendMessage(editor, expected) {
    pressEnter(editor);
    if (await waitUntilGone(editor, expected, 400)) return true;
    const btn = findSendButton(editor);
    if (btn) btn.click();
    return waitUntilGone(editor, expected, 400);
  }
  function autocompleteOpen() {
    for (const el of document.querySelectorAll('[role="listbox"], [role="option"][aria-selected="true"]')) {
      if (isVisible(el)) return true;
    }
    return false;
  }
  function userError(message) {
    const e = new Error(message);
    e.user = true;
    return e;
  }
  function block(e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }

  function onKeyDown(e) {
    if (bypass) return;
    if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyT') { block(e); toggleIncoming(); return; }
    if (e.key !== 'Enter' || !settings.outgoing) return;
    const editor = editorFrom(e.target) || editorFrom(document.activeElement);
    if (!editor) return;
    if (e.isComposing || e.keyCode === 229) return;
    if (e.shiftKey) return;
    if (busy) { block(e); setStatus('busy', T('stStillBusy')); return; }
    if (autocompleteOpen()) return;
    const text = readEditor(editor);
    if (!text) return;
    if (e.altKey) {
      block(e);
      previewPending = false;
      sendOriginalNext = false;
      pressEnter(editor);
      setStatus('info', T('stSentOriginal'));
      return;
    }
    const previewOnly = e.ctrlKey || e.metaKey;
    if (!previewOnly) {
      if (previewPending) { previewPending = false; return; }
      if (sendOriginalNext) { sendOriginalNext = false; return; }
      if (/^[\/!]/.test(text)) return;
    }
    block(e);
    runOutgoing(editor, text, previewOnly || settings.mode === 'preview');
  }

  async function runOutgoing(editor, text, previewOnly) {
    busy = true;
    previewPending = false;
    sendOriginalNext = false;
    setStatus('busy', T('stBusy'));
    try {
      let result;
      if (!editor.querySelector(EMBED_SELECTOR)) {
        result = await translateMessageOut(text);
        if (norm(readEditor(editor)) !== norm(text)) throw userError(T('stChanged'));
        if (norm(result) !== norm(text)) {
          const ok = await writeEditor(editor, result);
          if (!ok) throw userError(T('stInsertFail'));
        }
      } else {
        await translateInPlace(editor);
      }
      result = readEditor(editor);
      if (result.length > MAX_LEN) {
        previewPending = true;
        setStatus('warn', T('stTooLong', { n: result.length, max: MAX_LEN }));
        return;
      }
      if (previewOnly) {
        previewPending = true;
        setStatus('ok', T('stPreview'));
        return;
      }
      if (await sendMessage(editor, result)) {
        setStatus('ok', T('stSent', { text: short(result) }));
      } else {
        previewPending = true;
        setStatus('warn', T('stPressEnter'));
      }
    } catch (err) {
      const msg = String((err && err.message) || err);
      if (err && err.user) {
        sendOriginalNext = true;
        setStatus('error', msg);
      } else if (/context invalidated|Extension context/i.test(msg)) {
        setStatus('error', T('stReload'));
      } else {
        sendOriginalNext = true;
        setStatus('error', T('stOutFail'));
        console.warn('[Kick PL→EN]', msg);
      }
    } finally {
      busy = false;
    }
  }

  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener(
    'input',
    (e) => {
      const ed = editorFrom(e.target);
      if (ed && !readEditor(ed)) { previewPending = false; sendOriginalNext = false; }
    },
    true
  );

  // =====================================================================
  // Plakietka "PL→EN" przy czacie
  // =====================================================================
  const host = document.createElement('div');
  host.id = 'kick-pl-en-translator';
  host.style.cssText = 'position:fixed;top:0;left:0;z-index:2147483646;display:none;pointer-events:none;';
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      .wrap { display:flex; align-items:center; gap:6px; flex-direction:row-reverse; font:600 11px/1 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
      .pill { pointer-events:auto; cursor:pointer; display:inline-flex; align-items:center; gap:5px; padding:4px 8px; border-radius:999px;
              border:1px solid rgba(255,255,255,.15); background:#191b1f; color:#e8e8e8; opacity:.85; transition:opacity .15s, background .15s; }
      .pill:hover { opacity:1; background:#24272c; }
      .dot { width:7px; height:7px; border-radius:50%; background:#6b7280; }
      .on .dot { background:#53fc18; box-shadow:0 0 6px #53fc18; }
      .busy .dot { background:#facc15; box-shadow:0 0 6px #facc15; }
      .msg { max-width:340px; padding:5px 9px; border-radius:6px; background:#191b1f; color:#e8e8e8; border:1px solid rgba(255,255,255,.15);
             font-weight:500; line-height:1.3; white-space:normal; opacity:0; transform:translateY(3px); transition:opacity .2s, transform .2s; }
      .msg.show { opacity:1; transform:none; }
      .msg.ok { border-color:#53fc18; }
      .msg.warn { border-color:#facc15; }
      .msg.error { border-color:#f87171; color:#fecaca; }
    </style>
    <div class="wrap">
      <button class="pill" type="button"><span class="dot"></span><span class="lbl">PL→EN</span></button>
      <div class="msg" role="status" aria-live="polite"></div>
    </div>`;
  const pill = shadow.querySelector('.pill');
  const lbl = shadow.querySelector('.lbl');
  const msgEl = shadow.querySelector('.msg');
  pill.addEventListener('mousedown', (e) => e.preventDefault());
  pill.addEventListener('click', toggleIncoming);

  let msgTimer = null;
  function renderBadge() {
    pill.classList.toggle('on', !!settings.incoming);
    lbl.textContent = settings.incoming ? T('badgeOn') : T('badgeOff');
    pill.title = T('badgeTip') + (settings.outgoing ? T('badgeTipOut') : '');
  }
  function setStatus(kind, text) {
    renderBadge();
    pill.classList.toggle('busy', kind === 'busy');
    msgEl.className = 'msg show ' + kind;
    msgEl.textContent = text;
    clearTimeout(msgTimer);
    if (kind !== 'busy') {
      const ms = kind === 'error' || kind === 'warn' ? 7000 : 3500;
      msgTimer = setTimeout(() => { msgEl.className = 'msg'; }, ms);
    }
    position();
  }
  function position() {
    const editor = findEditor();
    const container = chatContainer();
    const anchor = editor || (container && isVisible(container) ? container : null);
    if (!anchor) { host.style.display = 'none'; return; }
    if (!host.isConnected) (document.body || document.documentElement).appendChild(host);
    const r = anchor.getBoundingClientRect();
    host.style.display = 'block';
    const w = host.offsetWidth || 120;
    const h = host.offsetHeight || 22;
    if (editor) {
      host.style.left = Math.max(4, Math.round(r.right - w)) + 'px';
      host.style.top = Math.max(4, Math.round(r.top - h - 8)) + 'px';
    } else {
      host.style.left = Math.max(4, Math.round(r.right - w - 8)) + 'px';
      host.style.top = Math.max(4, Math.round(r.bottom - h - 8)) + 'px';
    }
  }

  loadSettings();
  renderBadge();
  scheduleScan();
  let rafPending = false;
  const schedulePosition = () => {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => { rafPending = false; position(); });
  };
  setInterval(position, 500);
  window.addEventListener('resize', schedulePosition, { passive: true });
  document.addEventListener('scroll', schedulePosition, { passive: true, capture: true });
})();
