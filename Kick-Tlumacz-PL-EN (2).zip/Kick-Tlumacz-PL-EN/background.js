// Kick Tłumacz PL→EN: tłumaczenie w tle (service worker).
// Strona Kick nie może sama wołać zewnętrznych serwisów, więc robi to dodatek.

importScripts('slang.js');

const TIMEOUT_MS = 8000;
const cache = new Map();

function fetchWithTimeout(url, options = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  return fetch(url, { ...options, signal: ctrl.signal }).finally(() => clearTimeout(timer));
}

function decodeEntities(s) {
  return String(s)
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

// Darmowy, publiczny endpoint Google Translate (bez klucza).
async function viaGoogle(text, source) {
  const url =
    'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t' +
    '&sl=' + encodeURIComponent(source) +
    '&tl=en&q=' + encodeURIComponent(text);
  const res = await fetchWithTimeout(url);
  if (!res.ok) throw new Error('Google HTTP ' + res.status);
  const data = await res.json();
  const out = (Array.isArray(data[0]) ? data[0] : [])
    .map((part) => (part && part[0]) || '')
    .join('');
  if (!out.trim()) throw new Error('Google: pusta odpowiedź');
  return { text: out, detected: typeof data[2] === 'string' ? data[2] : source };
}

// MyMemory: darmowy, z dziennym limitem znaków.
async function viaMyMemory(text, source) {
  const pair = (source === 'auto' ? 'pl' : source) + '|en';
  const url =
    'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text) +
    '&langpair=' + encodeURIComponent(pair);
  const res = await fetchWithTimeout(url);
  if (!res.ok) throw new Error('MyMemory HTTP ' + res.status);
  const data = await res.json();
  if (Number(data.responseStatus) !== 200 || !data.responseData) {
    throw new Error('MyMemory: ' + (data.responseDetails || data.responseStatus));
  }
  return { text: decodeEntities(data.responseData.translatedText), detected: source === 'auto' ? '' : source };
}

// DeepL: najlepsza jakość, wymaga darmowego klucza API.
async function viaDeepL(text, source, key) {
  if (!key) throw new Error('Brak klucza DeepL');
  const k = key.trim();
  const host = k.endsWith(':fx') ? 'https://api-free.deepl.com' : 'https://api.deepl.com';
  const body = { text: [text], target_lang: 'EN-US' };
  if (source !== 'auto') body.source_lang = source.split('-')[0].toUpperCase();
  const res = await fetchWithTimeout(host + '/v2/translate', {
    method: 'POST',
    headers: { Authorization: 'DeepL-Auth-Key ' + k, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (res.status === 403) throw new Error('DeepL: nieprawidłowy klucz');
  if (res.status === 456) throw new Error('DeepL: wykorzystany limit znaków');
  if (!res.ok) throw new Error('DeepL HTTP ' + res.status);
  const data = await res.json();
  const t = data.translations && data.translations[0];
  if (!t) throw new Error('DeepL: pusta odpowiedź');
  return { text: t.text, detected: String(t.detected_source_language || '').toLowerCase() };
}

async function translateRaw(text, src, provider, deeplKey) {
  const cacheKey = [provider, src, text].join('\u0001');
  if (cache.has(cacheKey)) return cache.get(cacheKey);
  const all = { google: viaGoogle, mymemory: viaMyMemory, deepl: viaDeepL };
  const order = [provider, 'google', 'mymemory', 'deepl']
    .filter((p, i, arr) => all[p] && arr.indexOf(p) === i)
    .filter((p) => p !== 'deepl' || deeplKey);
  const errors = [];
  for (const p of order) {
    try {
      const r = await all[p](text, src, deeplKey);
      const result = { text: r.text.trim(), provider: p, detected: String(r.detected || '').toLowerCase() };
      if (cache.size > 800) cache.clear();
      cache.set(cacheKey, result);
      return result;
    } catch (e) {
      errors.push(e && e.name === 'AbortError' ? p + ': przekroczony czas' : String(e.message || e));
    }
  }
  throw new Error(errors.join(' | ') || 'Brak dostępnego tłumacza');
}

// Gotowe tłumaczenie: slang -> tłumacz -> poprawki -> (opcjonalnie) cenzura.
function finish(out, opts) {
  let t = out;
  if (opts.slang) t = self.KPE_SLANG.normalize(t, true); // resztki polskiego slangu w wyniku
  if (opts.censor) t = self.KPE_SLANG.censor(t);
  return t.replace(/[ \t]+/g, ' ').trim();
}

async function translate(text, source, provider, opts = {}) {
  const { deeplKey = '' } = await chrome.storage.local.get('deeplKey');
  const s = String(source || 'pl').toLowerCase();
  const src = s === 'auto' || /^[a-z]{2,3}(-[a-z]{2,4})?$/.test(s) ? s : 'pl';

  if (src === 'auto') {
    // Najpierw wykrycie języka na oryginale, potem (dla polskiego) tłumaczenie z rozpoznanym slangiem.
    const first = await translateRaw(text, 'auto', provider, deeplKey);
    let detected = first.detected;
    let r = first;
    if (detected.startsWith('en') && opts.hint === 'pl') {
      // Tłumacz uznał tekst za angielski, ale jest w nim dużo polskich słów (np. sam slang): tłumaczymy jako polski.
      const input = opts.slang ? self.KPE_SLANG.normalize(text) : text;
      r = await translateRaw(input, 'pl', provider, deeplKey);
      if (r.text.trim().toLowerCase() === text.trim().toLowerCase()) return { text, provider: r.provider, detected, unchanged: true };
      return { text: finish(r.text, opts), provider: r.provider, detected: 'pl', forced: true };
    }
    if (detected.startsWith('en')) return { text, provider: first.provider, detected, unchanged: true };
    if (opts.slang && (detected === 'pl' || detected === '')) {
      const normalized = self.KPE_SLANG.normalize(text);
      if (normalized !== text) r = await translateRaw(normalized, 'pl', provider, deeplKey);
    }
    return { text: finish(r.text, opts), provider: r.provider, detected };
  }

  const input = opts.slang && src === 'pl' ? self.KPE_SLANG.normalize(text) : text;
  const r = await translateRaw(input, src, provider, deeplKey);
  return { text: finish(r.text, opts), provider: r.provider, detected: r.detected || src };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== 'translate') return false;
  const opts = { slang: msg.slang !== false, censor: !!msg.censor, hint: msg.hint === 'pl' ? 'pl' : '' };
  translate(String(msg.text || ''), msg.source || 'pl', msg.provider || 'google', opts)
    .then((r) => sendResponse({ ok: true, ...r }))
    .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
  return true; // odpowiedź asynchroniczna
});

chrome.runtime.onInstalled.addListener(async () => {
  const defaults = {
    incoming: true, which: 'pl', display: 'below', slang: true, censor: false,
    outgoing: false, mode: 'send', provider: 'google', uiLang: 'auto'
  };
  const current = await chrome.storage.sync.get(Object.keys(defaults));
  const missing = {};
  for (const [k, v] of Object.entries(defaults)) if (current[k] === undefined) missing[k] = v;
  if (Object.keys(missing).length) await chrome.storage.sync.set(missing);
});
