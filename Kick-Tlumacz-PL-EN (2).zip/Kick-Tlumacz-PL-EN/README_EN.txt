KICK TRANSLATOR PL→EN (version 1.2)
===================================
Polish messages in Kick chat get an English translation right below them,
so people who don't speak Polish can read the chat.

Whoever wants to read the translations installs the add-on (a streamer or a viewer).
Only that person sees the translations, on their own computer. Nobody else in the chat sees them.
The menu is available in English and Polish (PL / EN buttons in the top right corner).

INSTALLATION (Microsoft Edge, Google Chrome, Brave, Opera)
1. Unzip this file into a folder you will keep, e.g. Documents\Kick-Translator.
   Do not delete the folder after installing: the browser loads the add-on from it.
2. Open the extensions page:
   Edge:   edge://extensions
   Chrome: chrome://extensions
3. Turn on "Developer mode" (Edge: bottom left, Chrome: top right).
4. Click "Load unpacked" and choose the folder that contains manifest.json.
5. Refresh the Kick tab (F5).
Updating from an older version? Replace the files in the same folder, click "Reload"
next to the add-on on the extensions page, then refresh Kick.

WHAT IT LOOKS LIKE
Every Polish message gets a line with a green EN tag and the translation.
English messages, bot commands (!discord) and emote-only messages are skipped.
Emotes and @mentions stay as they are.
Slang, abbreviations and swear words are translated into English equivalents, e.g.:
  "siema mordo, co tam?"    ->  "hey bro, what's up?"
  "nwm co sie dzieje wgl"   ->  "I don't know what's going on at all"
  "kurwa, ale sztos!"       ->  "fuck, that's awesome!"
Next to the chat there is a "PL→EN · On" badge. Click it (or press Alt+T) to turn translation on or off.

SETTINGS (click the add-on icon in the browser toolbar)
  Which messages:    Polish only, or everything that is not in English
  How to show:       below the original, or instead of it (hover to see the original)
  Slang:             understand Polish slang and abbreviations (on by default)
  Censor:            show swear words in translations as f*** (off by default)
  Translator:        Google (free, default), MyMemory (free, daily limit)
                     or DeepL (best quality, free API key from deepl.com/pro-api)
  Quick test:        try a translation without opening Kick
  My own messages:   optional (off by default): what you type in Polish is sent to the chat in English
  Menu language:     PL / EN

TROUBLESHOOTING
  "The add-on was updated. Refresh the page (F5)": refresh the Kick tab.
  "Could not translate messages": no internet or the translation service is not responding.
  Try a different translator in the settings.
  No translations under Polish messages: Kick may have changed its chat layout. Let the author know.

PRIVACY
Polish chat messages are sent only to the translation service you chose
(Google, MyMemory or DeepL). The DeepL key stays on this computer.

Works in a desktop browser (including the pop-out chat window).
Does not work in the Kick phone app or in a chat dock inside OBS.
