const DEFAULTS = {
  incoming: true, which: 'pl', display: 'below', slang: true, censor: false,
  outgoing: false, mode: 'send', provider: 'google', uiLang: 'auto'
};
const $ = (id) => document.getElementById(id);
const NAMES = { google: 'Google', mymemory: 'MyMemory', deepl: 'DeepL' };
let lang = 'en';
const T = (key, vars) => KPE_I18N.t(lang, key, vars);

function applyLanguage(pref) {
  lang = KPE_I18N.resolveLang(pref);
  document.documentElement.lang = lang;
  document.title = T('appName');
  for (const el of document.querySelectorAll('[data-i18n]')) el.textContent = T(el.dataset.i18n);
  for (const el of document.querySelectorAll('[data-i18n-ph]')) el.placeholder = T(el.dataset.i18nPh);
  for (const el of document.querySelectorAll('[data-i18n-aria]')) el.setAttribute('aria-label', T(el.dataset.i18nAria));
  for (const b of document.querySelectorAll('.lang button')) b.classList.toggle('active', b.dataset.lang === lang);
  $('testInfo').textContent = '';
}

function bindRadios(name, value) {
  for (const r of document.querySelectorAll(`input[name="${name}"]`)) {
    r.checked = r.value === value;
    r.addEventListener('change', () => r.checked && chrome.storage.sync.set({ [name]: r.value }));
  }
}
function bindCheckbox(id, value, after) {
  $(id).checked = !!value;
  $(id).addEventListener('change', (e) => {
    chrome.storage.sync.set({ [id]: e.target.checked });
    if (after) after(e.target.checked);
  });
}

async function init() {
  const s = { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
  const { deeplKey = '' } = await chrome.storage.local.get('deeplKey');
  applyLanguage(s.uiLang);

  for (const b of document.querySelectorAll('.lang button')) {
    b.addEventListener('click', () => {
      applyLanguage(b.dataset.lang);
      chrome.storage.sync.set({ uiLang: b.dataset.lang });
    });
  }

  bindCheckbox('incoming', s.incoming);
  bindRadios('which', s.which);
  bindRadios('display', s.display);
  bindCheckbox('slang', s.slang);
  bindCheckbox('censor', s.censor);
  bindRadios('mode', s.mode);
  $('outgoingBox').hidden = !s.outgoing;
  bindCheckbox('outgoing', s.outgoing, (on) => { $('outgoingBox').hidden = !on; });

  $('provider').value = s.provider;
  $('deeplBox').hidden = s.provider !== 'deepl';
  $('provider').addEventListener('change', (e) => {
    $('deeplBox').hidden = e.target.value !== 'deepl';
    chrome.storage.sync.set({ provider: e.target.value });
  });
  $('deeplKey').value = deeplKey;
  $('deeplKey').addEventListener('change', (e) => chrome.storage.local.set({ deeplKey: e.target.value.trim() }));

  $('testBtn').addEventListener('click', runTest);
  $('testIn').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); runTest(); }
  });
}

async function runTest() {
  const text = $('testIn').value.trim();
  if (!text) return;
  const out = $('testOut');
  $('testBtn').disabled = true;
  $('testInfo').textContent = T('testBusy');
  try {
    const resp = await chrome.runtime.sendMessage({
      type: 'translate', text, source: 'auto', provider: $('provider').value,
      slang: $('slang').checked, censor: $('censor').checked
    });
    if (!resp || !resp.ok) throw new Error((resp && resp.error) || 'No response');
    out.textContent = resp.text;
    out.className = 'out';
    const langs = T('langs');
    const name = resp.detected ? langs[resp.detected] || resp.detected : '';
    $('testInfo').textContent = resp.unchanged
      ? T('testAlreadyEn')
      : (name ? T('testDetected', { lang: name }) + ' ' : '') + T('testProvider', { name: NAMES[resp.provider] || resp.provider });
  } catch (e) {
    out.textContent = T('testFail') + ' ' + String(e.message || e);
    out.className = 'out err';
    $('testInfo').textContent = '';
  } finally {
    out.hidden = false;
    $('testBtn').disabled = false;
  }
}

init();
